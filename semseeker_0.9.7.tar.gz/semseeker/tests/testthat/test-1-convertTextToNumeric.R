# test_that("convertTextToNumeric", {
#
#   text_value <-  "1,200,000.34"
#   testthat::expect_true( semseeker:::convertTextToNumeric(text_value)==1200000.34 )
#
#   text_value <-  "1.200.000,34"
#   testthat::expect_true( semseeker:::convertTextToNumeric(text_value)==1200000.34 )
#
# }
# )
