library(testthat)
library(future)
library(semseeker)
test_check("semseeker")
