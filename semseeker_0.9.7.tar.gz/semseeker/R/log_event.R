# log_event <- function()
# {
#   ssEnv <- get_session_info()
#   sink(file.path(ssEnv$session_folder,"session_output.log"), split = TRUE)
#   sink()
# }
